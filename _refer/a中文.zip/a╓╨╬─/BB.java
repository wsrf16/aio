package com.aio.portable.swiss.sandbox.a中文;

@Flag(age = 99)
public class BB {
    public int aa = 88;
}
