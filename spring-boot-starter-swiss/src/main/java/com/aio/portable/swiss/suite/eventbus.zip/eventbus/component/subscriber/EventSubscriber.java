package com.aio.portable.swiss.suite.eventbus.component.subscriber;

import com.aio.portable.swiss.suite.eventbus.component.event.Event;
import com.aio.portable.swiss.suite.eventbus.component.consumer.EventConsumer;
import com.aio.portable.swiss.suite.eventbus.component.consumer.RestTemplateEventConsumer;
import com.aio.portable.swiss.suite.eventbus.refer.EventBusConfig;
import com.aio.portable.swiss.suite.eventbus.refer.exception.NotExistEventNamespaceException;
import com.aio.portable.swiss.suite.eventbus.refer.persistence.PersistentContainer;
import com.aio.portable.swiss.suite.storage.persistence.NodePersistence;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.util.StringUtils;

import javax.validation.constraints.NotNull;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class EventSubscriber extends AbstractEventSubscriber {
    private final static String EMPTY = "";
    @JsonIgnore
    protected boolean concurrent = true;

    @JsonIgnore
    NodePersistence nodePersistence;

    @JsonIgnore
    private PersistentContainer persistentContainer;

    public boolean isConcurrent() {
        return concurrent;
    }

    public void setConcurrent(boolean concurrent) {
        this.concurrent = concurrent;
    }

    public NodePersistence getNodePersistence() {
        return nodePersistence;
    }

    public void setNodePersistence(NodePersistence nodePersistence) {
        this.nodePersistence = nodePersistence;
        this.persistentContainer = PersistentContainer.buildEventSubscriberPersistentContainer(nodePersistence);
    }

    public EventSubscriber() {
    }

    private String mutateTable() {
        return getSubscriber();
    }

    private String[] spellTables() {
        return new String[]{EventBusConfig.EVENT_BUS_TABLE, getNamespace(), getSubscriber()};
    }

    public EventSubscriber(@NotNull NodePersistence nodePersistence, @NotNull String namespace, @NotNull List<String> topics, @NotNull String name) {
        super(namespace, topics, name);
        setNodePersistence(nodePersistence);
    }


    @Override
    public void add(EventConsumer eventConsumer) {
        String consumer = eventConsumer.getConsumer();
        String[] tables = spellTables();
//        String table = mutateTable();
        persistentContainer.set(consumer, eventConsumer, tables);
    }

    public void set(EventConsumer eventConsumer) {
        String consumer = eventConsumer.getConsumer();
        if (StringUtils.isEmpty(consumer)) {
            throw new IllegalArgumentException("consumer is empty.");
        }
        if (exists(consumer)) {
//            persist(eventNamespace);
            String[] tables = spellTables();
            persistentContainer.set(consumer, eventConsumer, tables);
        } else {
            throw new NotExistEventNamespaceException(MessageFormat.format("consumer {0} is not exist.", eventConsumer.getConsumer()));
        }
    }

    @Override
    public void remove(EventConsumer eventConsumer) {
        String[] tables = spellTables();
//        String table = mutateTable();
        String key = eventConsumer.getConsumer();
        persistentContainer.remove(key, tables);
    }

    @Override
    public void remove(String consumer) {
        String[] tables = spellTables();
//        String table = mutateTable();
        String key = consumer;
        persistentContainer.remove(key, tables);
    }

    @Override
    public void clear() {
        String[] tables = spellTables();
//        String table = mutateTable();
        persistentContainer.clearTable(EMPTY, tables);
    }

    @Override
    public EventConsumer get(String consumer) {
        String[] tables = spellTables();
//        String table = mutateTable();
        return persistentContainer.get(consumer, EventConsumer.class, tables);
    }

    public void enable(String consumer, boolean enabled) {
        EventConsumer eventConsumer = get(consumer);
        eventConsumer.setEnabled(enabled);
        set(eventConsumer);
    }

    @Override
    public boolean exists() {
        String table = mutateTable();
        return persistentContainer.existsTable(table);
    }

    @Override
    public boolean exists(String name) {
        String[] tables = spellTables();
//        String table = mutateTable();
        return persistentContainer.exists(name, tables);
    }

    @Override
    public Map<String, EventConsumer> collection() {
        String[] tables = spellTables();
//        String table = mutateTable();
        return persistentContainer.getAll(EMPTY, EventConsumer.class, tables);
    }

    @Override
    public <E extends Event> Map<String, EventConsumer> onReceive(E event) {
        return dispatch(event);
    }

    private <E extends Event> Map<String, EventConsumer> dispatch(E event) {
        if (!exists())
            return null;
        if (!isEnabled())
            return null;

        Stream<EventConsumer> stream = this.collection()
                .values()
                .stream()
                .filter(c -> c.isEnabled());
        stream = concurrent ? stream.parallel() : stream;
        stream.forEach(consumer -> {
            if (consumer instanceof RestTemplateEventConsumer) {
                Object push = consumer.push(event);
            } else {
                Object push = consumer.push(event);
            }
        });

        return this.collection();
    }



}
