package com.aio.portable.swiss.suite.eventbus.refer;

public class EventBusConfig {
    public final static String KEY_VALUE_EVENT_NAMESPACE_TABLE = "namespace-{0}";
    public final static String EVENT_NAMESPACE_KEY = "{0}";

    public final static String KEY_VALUE_EVENT_SUBSCRIBER_TABLE = "subscriber-{0}";
    public final static String EVENT_SUBSCRIBER_KEY = "{0}";

    public final static String EVENT_BUS_TABLE = "event-bus";
    public final static String EVENT_BUS_KEY = "{0}";
}
