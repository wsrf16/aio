package com.aio.portable.swiss.suite.eventbus.refer.exception;

import com.aio.portable.swiss.hamlet.bean.BizStatusOriginEnum;
import com.aio.portable.swiss.hamlet.exception.BizException;

import java.text.MessageFormat;

public class NotExistEventConsumerException extends BizException {
    public NotExistEventConsumerException(String consumer) {
        super(BizStatusOriginEnum.staticFailed().getCode(), MessageFormat.format("consumer {0} is not exist.", consumer));
    }
}
